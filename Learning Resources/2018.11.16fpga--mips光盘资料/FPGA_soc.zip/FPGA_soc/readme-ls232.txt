PMON> h devcp
           devcp  srcfile dstfile [bs=0x20000] [count=-1] [seek=0] [skip=0] [quiet=0] copy form src to dst
PMON> mtd mtd_erase
mtd: Command not found. Try 'h' for help!
PMON> h mtd_erase  
       mtd_erase  [option] mtd_dev                                                    (null)
                               -h    HELP
                               -H    HELP
                               -j    format the device for jffs2,the clearmark-size is 12 Byte
PMON> set mtdparts
  mtdparts = nand-flash:10M@0(kernel)ro,-(rootfs)
PMON> devls
Device name  Type
dmfe0        IFNET
loopdev0     DISK
PMON> set al
        al = /dev/mtd0 
PMON> set append
    append = "console=ttyS0,115200 rdinit=/sbin/init initcall_debug=1 loglevel=20"


mtd_erase /dev/mtd0r
mtd_erase /dev/mtd1r

ifaddr dmfe0 10.0.0.2
devcp tftp://10.0.0.1/vmlinux /dev/mtd0
set al /dev/mtd0
set append "console=ttyS0,115200 rdinit=/sbin/init initcall_debug=1 loglevel=20"
http://ftp.loongnix.org/embed/ls1b/
modules:
make -C /usr/src/kernels/linux-2.6.32 SUBDIRS=/home/loongson/test  ARCH=mips CROSS_COMPILE=/home/opt/gcc-4.3-ls232/bin/mipsel-linux-
